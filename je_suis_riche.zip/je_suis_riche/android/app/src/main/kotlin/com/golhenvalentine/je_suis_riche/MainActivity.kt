package com.golhenvalentine.je_suis_riche

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
