package com.golhenvalentine.defi_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
