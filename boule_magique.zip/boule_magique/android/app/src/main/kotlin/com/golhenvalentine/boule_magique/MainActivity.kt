package com.golhenvalentine.boule_magique

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
