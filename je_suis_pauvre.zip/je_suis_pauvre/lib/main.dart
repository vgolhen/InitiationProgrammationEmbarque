import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Je suis pauvre'),
          backgroundColor: Colors.grey[700],
        ),
        backgroundColor: Colors.pink[100],
        body: Center(
          child: Image(
            image: AssetImage("images/Cartman.jpg"),
          ),
        ),
      ),
    ),
  );
}
