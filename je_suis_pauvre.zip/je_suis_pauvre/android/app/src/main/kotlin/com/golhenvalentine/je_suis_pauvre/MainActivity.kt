package com.golhenvalentine.je_suis_pauvre

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
