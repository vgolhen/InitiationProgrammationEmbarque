package com.golhenvalentine.jeu_de_des

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
