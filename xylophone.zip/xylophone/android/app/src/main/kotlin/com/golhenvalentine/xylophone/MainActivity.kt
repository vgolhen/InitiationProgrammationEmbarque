package com.golhenvalentine.xylophone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
