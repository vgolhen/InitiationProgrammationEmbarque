import 'package:flutter/material.dart';

void main() {
  runApp(
    MyApp(),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.green,
        body: SafeArea(
          child: Row(
            //mainAxisSize: MainAxisSize.min,
            //verticalDirection: VerticalDirection.up,
            //verticalDirection: VerticalDirection.down,
            //mainAxisAlignment: MainAxisAlignment.center, //alignement au centre de l'écran
            //mainAxisAlignment: MainAxisAlignment.end, //alignement en bas de l'écran
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly, //les espaces autours des enfants sont identiques
            //mainAxisAlignment: MainAxisAlignment.spaceBetween, //les espaces sont éloignés de celui au centre (haut - centre - bas)
            //mainAxisAlignment: MainAxisAlignment.spaceAround,
            //crossAxisAlignment: CrossAxisAlignment.start, //définit que les éléments de "children" seront alignés à partir de la gauche
            //crossAxisAlignment: CrossAxisAlignment.center, //alignement au centre de la colonne
            //crossAxisAlignment: CrossAxisAlignment.end, //alignement à la droite de la colonne
            crossAxisAlignment: CrossAxisAlignment.stretch, //les widgets sont allongés horizontalement pour occuper tout l'espace possible
            children: <Widget>[
              Container(
              height: 100.0,
              width: 100.0,
              color: Colors.white,
              ),
              SizedBox(width: 20.0),
              Container(
                height: 100.0,
                width: 100.0,
                color: Colors.red,
              ),
              Container(
                height: 100.0,
                width: 100.0,
                color: Colors.blue,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
