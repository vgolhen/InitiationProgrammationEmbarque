package com.golhenvalentine.calculette

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
