class Question {
  String questionTexte;
  bool questionReponse;

  //constructeur en Dart
  Question({String t, bool r}) {
    questionTexte = t;
    questionReponse = r;
  }
}