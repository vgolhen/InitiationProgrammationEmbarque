import 'question.dart';

class ToutesQuestions {
  int _numeroQuestion = 0;
  List<Question> _questionList = [
    Question(
        t : 'Une vache descend des escalers mais ne les monte pas.', r:false),
    Question(
        t: 'Environ un quart des os humains sont dans les pieds.', r: true),
    Question(
        t: 'Le sang d\'une limace est vert.', r: true),
  ];

  void prochaineQuestion(){
    if(_numeroQuestion < _questionList.length - 1){
      _numeroQuestion++;
    }
  }

  String getQuestion() {
    return _questionList[_numeroQuestion].questionTexte;
  }

  bool getReponse() {
    return _questionList[_numeroQuestion].questionReponse;
  }
}