package com.golhenvalentine.carte_de_visite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
