package com.golhenvalentine.devinette

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
