import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blue[500],
        appBar: AppBar(
          title: Text('Ask Me Anything'),
          backgroundColor: Colors.indigo[800],
        ),
        body: BouleMagique(),
      ),
    ),
  );
}

class BouleMagique extends StatefulWidget {
  @override
  _BouleMagique createState() => _BouleMagique();
}

class _BouleMagique extends State<BouleMagique> {
  @override
  int indication = 1;
  Widget build(BuildContext context) {
    return Center(
      child: FlatButton(
        onPressed: () {
          setState(() {
            indication=Random().nextInt(5)+1;
          });
        },
        child: Image.asset("images/ball$indication.png"),
      ),
    );
  }
}
